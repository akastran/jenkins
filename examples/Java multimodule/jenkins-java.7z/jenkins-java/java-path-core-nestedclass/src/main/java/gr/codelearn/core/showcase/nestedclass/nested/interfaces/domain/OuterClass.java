package gr.codelearn.core.showcase.nestedclass.nested.interfaces.domain;

public class OuterClass {

	// Nested interface inside class, can have any access modifier, and are always static
	public interface NestedInterface {
		String method1();
	}
}

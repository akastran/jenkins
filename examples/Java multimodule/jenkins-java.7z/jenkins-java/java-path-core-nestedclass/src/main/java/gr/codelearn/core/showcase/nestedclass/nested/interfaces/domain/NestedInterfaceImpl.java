package gr.codelearn.core.showcase.nestedclass.nested.interfaces.domain;

public class NestedInterfaceImpl implements OuterClass.NestedInterface {
	@Override
	public String method1() {
		return "method1";
	}
}

package gr.codelearn.core.showcase.nestedclass.nested.classes.domain;

public class OuterInterfaceImpl implements OuterInterface {
	// Stub interface to showcase upcasting in main method
}

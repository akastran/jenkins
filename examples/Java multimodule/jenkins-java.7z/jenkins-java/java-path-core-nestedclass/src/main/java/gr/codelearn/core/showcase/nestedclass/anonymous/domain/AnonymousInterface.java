package gr.codelearn.core.showcase.nestedclass.anonymous.domain;

public interface AnonymousInterface {
	String method1();

	String method2();

	String method3();
}

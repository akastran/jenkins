package gr.codelearn.core.showcase.exception.domain;

public class ClassB extends ClassA {
	// Used in the unchecked exceptions tester to showcase ClassCastException
}

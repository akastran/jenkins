package gr.codelearn.core.showcase.exception.exceptions;

public class NumberIsZeroException extends Exception {
	public NumberIsZeroException(String errorMessage) {
		super(errorMessage);
	}
}

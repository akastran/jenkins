package gr.codelearn.core.showcase.exception.exceptions;

public class NumberBelowZeroException extends Exception {
	public NumberBelowZeroException(String errorMessage) {
		super(errorMessage);
	}
}

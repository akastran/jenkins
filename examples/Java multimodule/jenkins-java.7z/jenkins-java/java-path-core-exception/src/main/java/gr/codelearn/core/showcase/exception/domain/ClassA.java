package gr.codelearn.core.showcase.exception.domain;

public class ClassA {
	// Used in the unchecked exceptions tester to showcase ClassCastException
}

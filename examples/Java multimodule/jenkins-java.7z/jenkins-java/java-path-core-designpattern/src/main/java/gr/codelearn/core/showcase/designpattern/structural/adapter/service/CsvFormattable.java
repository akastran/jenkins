package gr.codelearn.core.showcase.designpattern.structural.adapter.service;

//adaptee
public interface CsvFormattable {
	String formatCsvText(String text);
}

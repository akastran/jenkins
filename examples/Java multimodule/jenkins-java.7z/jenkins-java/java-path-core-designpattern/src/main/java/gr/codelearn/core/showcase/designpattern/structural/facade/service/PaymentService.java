package gr.codelearn.core.showcase.designpattern.structural.facade.service;

//service/subsystem
public class PaymentService {

	public static boolean makePayment() {
		/*Code that connects with payment gateway for payment*/
		return true;
	}

}

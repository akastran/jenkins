package gr.codelearn.core.showcase.designpattern.structural.adapter.service;

//target
public interface TextFormattable {
	String formatText(String text);
}

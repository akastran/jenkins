package gr.codelearn.core.showcase.designpattern.behavioral.strategy.service;

//strategy
public interface EncryptionStrategy {
	String encryptData(String text);
}

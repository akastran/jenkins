package gr.codelearn.core.showcase.designpattern.behavioral.command.command;

//command
public interface CommandBase {
	void execute();

	void undo();
}


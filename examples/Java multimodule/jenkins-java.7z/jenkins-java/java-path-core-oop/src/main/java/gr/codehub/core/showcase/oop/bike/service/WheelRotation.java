package gr.codehub.core.showcase.oop.bike.service;

import gr.codehub.core.showcase.oop.bike.domain.Bike;

public interface WheelRotation {
	void rotate(Bike bike);
}

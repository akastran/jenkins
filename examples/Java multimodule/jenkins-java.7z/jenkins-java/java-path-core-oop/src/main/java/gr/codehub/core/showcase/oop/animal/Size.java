package gr.codehub.core.showcase.oop.animal;

public enum Size {
	SMALL, MEDIUM, LARGE
}
